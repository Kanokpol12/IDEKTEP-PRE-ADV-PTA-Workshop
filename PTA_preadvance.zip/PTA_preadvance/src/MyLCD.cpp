#include "MyLCD.h"

MyLCD::MyLCD(uint8_t addr, uint8_t cols, uint8_t rows) {
    lcd = new LiquidCrystal_I2C(addr, cols, rows);
}

void MyLCD::begin() {
    lcd->init();
    lcd->backlight();
    showMessage("Booting...", "");
}

void MyLCD::showMessage(String line1, String line2) {
    lcd->clear();
    lcd->setCursor(0, 0);
    lcd->print(line1);
    lcd->setCursor(0, 1);
    lcd->print(line2);
}

void MyLCD::showSensorData(float temp, float hum, int ldrRaw, float ldrPct) {
    lcd->setCursor(0, 0);
    if (temp == -999 || hum == -999) {
        lcd->print("T:ERR H:ERR     ");
    } else {
        char buffer[17];
        snprintf(buffer, sizeof(buffer), "T:%.1fC H:%.0f%%   ", temp, hum);
        lcd->print(buffer);
    }

    lcd->setCursor(0, 1);
    char buffer2[17];
    snprintf(buffer2, sizeof(buffer2), "LDR:%d (%d%%)  ", ldrRaw, (int)ldrPct);
    lcd->print(buffer2);
}

void MyLCD::showCommand(String cmd) {
    lcd->clear();
    lcd->setCursor(0, 0);
    lcd->print("Cmd received:");
    lcd->setCursor(0, 1);
    if (cmd.length() > 16) cmd = cmd.substring(0, 16);
    lcd->print(cmd);
}