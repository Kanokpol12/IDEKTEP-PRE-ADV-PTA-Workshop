#include "Sensors.h"

Sensors::Sensors(int dhtPin, int dhtType, int ldrPin) {
    _dhtPin = dhtPin;
    _dhtType = dhtType;
    _ldrPin = ldrPin;
    dht = new DHT(_dhtPin, _dhtType);
}

void Sensors::begin() {
    dht->begin();
    analogSetPinAttenuation(_ldrPin, ADC_11db);
    analogReadResolution(12);
}

float Sensors::readTemp() {
    float t = dht->readTemperature();
    return isnan(t) ? -999 : t;
}

float Sensors::readHum() {
    float h = dht->readHumidity();
    return isnan(h) ? -999 : h;
}

int Sensors::readLdrRaw() {
    return analogRead(_ldrPin);
}

float Sensors::readLdrPercent() {
    int raw = readLdrRaw();
    return (raw / 4095.0) * 100.0;
}