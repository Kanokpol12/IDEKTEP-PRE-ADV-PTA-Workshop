#include <Arduino.h>
#include "Secrets.h"
#include "Sensors.h"
#include "Actuators.h"
#include "MyLCD.h"
#include "Network.h"

// ===== Pin Definitions =====
#define DHTPIN 23
#define DHTTYPE DHT22
#define LDRPIN 34
#define BUZZERPIN 18
#define LED_BOARD_PIN 2
#define LED1_PIN 16
#define LED2_PIN 17

// ===== Objects =====
Sensors sensors(DHTPIN, DHTTYPE, LDRPIN);
Actuators actuators(BUZZERPIN, LED_BOARD_PIN, LED1_PIN, LED2_PIN);
MyLCD lcd(0x27, 16, 2);
Network network(WIFI_SSID, WIFI_PASS, MQTT_SERVER, MQTT_PORT);

// ===== Variables =====
unsigned long lastSend = 0;
unsigned long commandDisplayTime = 0;
bool showingCommand = false;

// ===== Callback Function =====
// ฟังก์ชันนี้ต้องอยู่นอก Class หรือเป็น Static เพื่อให้ MQTT เรียกใช้ได้ง่าย
void mqttCallback(char* topic, byte* payload, unsigned int length) {
    String incoming = "";
    for (unsigned int i = 0; i < length; i++) incoming += (char)payload[i];

    Serial.println("MQTT Recv: " + incoming);

    // แสดงผลบนจอ LCD
    lcd.showCommand(incoming);
    commandDisplayTime = millis();
    showingCommand = true;

    // ตรวจสอบคำสั่ง
    if (incoming == "BUZZER_ON") {
        actuators.buzzerOn();
        Serial.println("CMD: Buzzer ON");
    } else if (incoming == "BUZZER_OFF") {
        actuators.buzzerOff();
        Serial.println("CMD: Buzzer OFF");
    } else if (incoming == "BUZZER_BLINK") {
        actuators.buzzerBlink();
        Serial.println("CMD: Buzzer BLINK");
    } else if (incoming == "LED_ON") {
        actuators.ledsOn();
        Serial.println("CMD: LED ON");
    } else if (incoming == "LED_OFF") {
        actuators.ledsOff();
        Serial.println("CMD: LED OFF");
    }
}

void setup() {
    Serial.begin(115200);

    // เริ่มต้นอุปกรณ์ต่างๆ
    lcd.begin();
    actuators.begin();
    sensors.begin();

    // ตั้งค่า Network และ Callback
    network.setCallback(mqttCallback);
    network.begin();

    lcd.showMessage("Ready", WiFi.localIP().toString());
    delay(2000);
}

void loop() {
    // ให้ Network จัดการการเชื่อมต่อและ Loop MQTT
    network.update();
    
    // Subscribe ถ้าเพิ่งต่อใหม่ (ใส่ Logic ง่ายๆ ไว้ตรงนี้ หรือย้ายไปใน Network class ก็ได้)
    static bool initialSub = false;
    if (network.isConnected() && !initialSub) {
        network.subscribe(TOPIC_CMD_1);
        network.subscribe(TOPIC_CMD_2);
        lcd.showMessage("MQTT Connected", "Waiting cmds...");
        delay(1000);
        initialSub = true; 
        // หมายเหตุ: ในการใช้งานจริง ถ้า MQTT หลุดแล้วต่อใหม่ ต้องเซ็ต flag ให้ Subscribe ใหม่ด้วย
    }

    // ส่งค่าเซนเซอร์ทุก 2 วินาที
    if (millis() - lastSend >= 2000) {
        lastSend = millis();

        float t = sensors.readTemp();
        float h = sensors.readHum();
        float ldrPct = sensors.readLdrPercent();
        int ldrRaw = sensors.readLdrRaw();

        // 1. ส่งแบบแยก Topic
        char strBuf[10];
        itoa((int)t, strBuf, 10); network.publish(TOPIC_TEMP, strBuf);
        itoa((int)h, strBuf, 10); network.publish(TOPIC_HUM, strBuf);
        itoa((int)ldrPct, strBuf, 10); network.publish(TOPIC_LDR, strBuf);

        // 2. อัพเดทหน้าจอ (ถ้าไม่ได้กำลังโชว์คำสั่งอยู่)
        if (showingCommand) {
            if (millis() - commandDisplayTime > 5000) {
                showingCommand = false; // หมดเวลาโชว์คำสั่ง กลับมาโชว์ค่าเซนเซอร์
            }
        } else {
            lcd.showSensorData(t, h, ldrRaw, ldrPct);
        }
    }
}