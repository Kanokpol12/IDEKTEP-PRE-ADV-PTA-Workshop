#include "Network.h"

Network::Network(const char* ssid, const char* pass, const char* mqttServer, int mqttPort) 
    : client(espClient) {
    _ssid = ssid;
    _pass = pass;
    _mqttServer = mqttServer;
    _mqttPort = mqttPort;
}

void Network::setCallback(MQTT_CALLBACK_SIGNATURE) {
    client.setCallback(callback);
}

void Network::begin() {
    Serial.print("Connecting WiFi");
    WiFi.begin(_ssid, _pass);
    while (WiFi.status() != WL_CONNECTED) {
        delay(250);
        Serial.print(".");
    }
    Serial.println("\nWiFi Connected: " + WiFi.localIP().toString());
    
    client.setServer(_mqttServer, _mqttPort);
}

void Network::update() {
    if (!client.connected()) {
        Serial.print("Connecting MQTT...");
        String clientId = "ESP32-" + String((uint32_t)ESP.getEfuseMac(), HEX);
        if (client.connect(clientId.c_str())) {
            Serial.println("connected");
            // Re-subscribe topics here if handled internally, 
            // but we will let main handle subscriptions logic via public method if needed
            // or you can add a re-subscribe logic here.
        } else {
            Serial.print("failed, rc=");
            Serial.println(client.state());
            delay(2000);
        }
    }
    client.loop();
}

void Network::publish(const char* topic, const char* payload) {
    if (client.connected()) {
        client.publish(topic, payload);
    }
}

void Network::subscribe(const char* topic) {
    if (client.connected()) {
        client.subscribe(topic);
    }
}

bool Network::isConnected() {
    return client.connected();
}