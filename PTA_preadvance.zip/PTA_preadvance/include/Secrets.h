#ifndef SECRETS_H
#define SECRETS_H

// WiFi
const char* WIFI_SSID = "Boss second.hand.kp";
const char* WIFI_PASS = "irenemywife";

// MQTT
const char* MQTT_SERVER = "broker.emqx.io";
const int MQTT_PORT = 1883;

// Topics
const char* TOPIC_SENSORS_JSON = "esp/adv1/sen/name";
const char* TOPIC_TEMP = "esp/adv1/sen1/name";
const char* TOPIC_HUM = "esp/adv1/sen2/name";
const char* TOPIC_LDR = "esp/adv1/sen3/name";

const char* TOPIC_CMD_1 = "esp/adv1/com/name";
const char* TOPIC_CMD_2 = "esp/adv1/com2/name";

#endif