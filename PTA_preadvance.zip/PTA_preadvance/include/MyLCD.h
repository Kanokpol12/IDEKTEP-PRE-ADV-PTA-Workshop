#ifndef MYLCD_H
#define MYLCD_H

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>

class MyLCD {
private:
    LiquidCrystal_I2C* lcd;

public:
    MyLCD(uint8_t addr, uint8_t cols, uint8_t rows);
    void begin();
    void showMessage(String line1, String line2);
    void showSensorData(float temp, float hum, int ldrRaw, float ldrPct);
    void showCommand(String cmd);
};

#endif