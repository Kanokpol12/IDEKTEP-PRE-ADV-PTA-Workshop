#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>
#include <DHT.h>

class Sensors {
private:
    int _dhtPin;
    int _dhtType;
    int _ldrPin;
    DHT* dht; // ใช้ Pointer เพื่อสร้าง Object ภายหลัง

public:
    Sensors(int dhtPin, int dhtType, int ldrPin);
    void begin();
    float readTemp();
    float readHum();
    int readLdrRaw();
    float readLdrPercent();
};

#endif