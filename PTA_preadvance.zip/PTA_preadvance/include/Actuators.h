#ifndef ACTUATORS_H
#define ACTUATORS_H

#include <Arduino.h>

class Actuators {
private:
    int _buzzerPin;
    int _ledBoardPin;
    int _led1Pin;
    int _led2Pin;

public:
    Actuators(int buzzerPin, int ledBoardPin, int led1Pin, int led2Pin);
    void begin();
    void buzzerOn();
    void buzzerOff();
    void buzzerBlink();
    void ledsOn();
    void ledsOff();
};

#endif