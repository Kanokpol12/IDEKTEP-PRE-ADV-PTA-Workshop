#ifndef NETWORK_H
#define NETWORK_H

#include <WiFi.h>
#include <PubSubClient.h>

class Network {
private:
    WiFiClient espClient;
    PubSubClient client;
    const char* _ssid;
    const char* _pass;
    const char* _mqttServer;
    int _mqttPort;

public:
    Network(const char* ssid, const char* pass, const char* mqttServer, int mqttPort);
    void setCallback(MQTT_CALLBACK_SIGNATURE); // รับ function callback
    void begin();
    void update(); // เรียกใน loop
    void publish(const char* topic, const char* payload);
    void subscribe(const char* topic);
    bool isConnected();
};

#endif