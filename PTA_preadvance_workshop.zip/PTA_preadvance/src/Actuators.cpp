#include "Actuators.h"

Actuators::Actuators(int buzzerPin, int ledBoardPin, int led1Pin, int led2Pin) {
    _buzzerPin = buzzerPin;
    _ledBoardPin = ledBoardPin;
    _led1Pin = led1Pin;
    _led2Pin = led2Pin;
}

void Actuators::begin() {
    pinMode(_buzzerPin, OUTPUT);
    pinMode(_ledBoardPin, OUTPUT);
    pinMode(_led1Pin, OUTPUT);
    pinMode(_led2Pin, OUTPUT);
    
    digitalWrite(_buzzerPin, LOW);
    digitalWrite(_ledBoardPin, LOW);
    digitalWrite(_led1Pin, LOW);
    digitalWrite(_led2Pin, LOW);
}

void Actuators::buzzerOn() {
    digitalWrite(_buzzerPin, HIGH);
}

void Actuators::buzzerOff() {
    digitalWrite(_buzzerPin, LOW);
}

void Actuators::buzzerBlink() {
    // หมายเหตุ: การใช้ delay จะบล็อกการทำงานอื่นชั่วคราว
    for(int i=0; i<3; i++){
        digitalWrite(_buzzerPin, LOW); delay(200);
        digitalWrite(_buzzerPin, HIGH); delay(200);
    }
    digitalWrite(_buzzerPin, LOW);
}

void Actuators::ledsOn() {
    digitalWrite(_ledBoardPin, HIGH);
    digitalWrite(_led1Pin, HIGH);
    digitalWrite(_led2Pin, HIGH);
}

void Actuators::ledsOff() {
    digitalWrite(_ledBoardPin, LOW);
    digitalWrite(_led1Pin, LOW);
    digitalWrite(_led2Pin, LOW);
}